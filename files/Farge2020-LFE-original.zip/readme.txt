/// - "farge_jgr_2020_lfe_catalog.txt" is the original catalog of "Farge2020-LFE".
Covered period: from 2005-01-14 to 2007-04-15.

--> This catalog is a subset of Frank et al., 2014 [ref 2] catalog
("Frank2014-LFE"), for which Farge et al., 2020 [ref 1] estimated seismic
moments and corner frequencies. Please refer to Frank et al., 2014 for more
details on detection methods, and to Farge et al., 2020 for details on selection
and characterization of the sub-catalog. Upon use of the catalog, please cite
both papers at the end of this file.

--> Data format
Year
Month
Day
Hour
Minute
Second (with milliseconds) *
Latitude (degrees)
Longitude (degrees)
Depth (km)
Seismic moment (M_0, in N.m)
Corner frequency (MIF**: Mean of instantaneous frequency, Hz) 
Corner frequency (MVS***: Maximum of velocity spectrum frequency, Hz)

*: Timezone: UTC. Detection time is referenced to the start of the waveform
template for the corresponding LFE family and does not represent the hypocentral
time. See Frank et al., 2014 [ref 2] for details.

** and ***: see Farge et al., 2020 [ref 1] for more details on how both
estimations of corner frequencies were obtained.


/// - "farge_jgr_2020_lfe_bulletin.txt" gathers the information about stations,
channels and time-window used to compute seismic moment and corner frequency of
events.

--> Each entry in this bulletin corresponds to an event. The first line
specifies the index of the event in the catalog and its detection time. For each
event, 10 records are used to estimate source parameters, the 10 following lines
list the station and channel of each record, and the beginning of the 5 seconds
time-window used for characterization.

--> Data format

- 1st line -  Year, Month, Day, Hour, Minute, Seconds (with
milliseconds) of detection*
- 10 next lines - Station, Channel, 5s time-window start time (seconds from
  beginning of day)

*: Timezone: UTC. Detection time is referenced to the start of the waveform
template for the corresponding LFE family and does not represent the hypocentral
time. See Frank et al., 2014 [ref 2] for details.


[references] --------------------------------

1 -  Farge, G., Shapiro, N.M, Frank, W. B. (2020). Moment-duration
scaling of low-frequency earthquakes in Guerrero, Mexico. Journal of Geophysical
Research: Solid Earth, ?125(8), e2019JB019099, https//doi.org/10.1029/2019JB019099

2 - Frank, W. B., Shapiro, N. M., Husker, A. L., Kostoglodov, V., Romanenko, A.,
& Campillo, M. (2014). Using systematically characterized low‐frequency
earthquakes as a fault probe in Guerrero, Mexico. Journal of Geophysical
Research: Solid Earth, 119(10), 7686-7700. https//doi.org/10.1002/2014JB011457
